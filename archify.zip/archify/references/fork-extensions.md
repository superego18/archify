# Fork extensions (dev_chanju)

Fields below exist only in the superego18 fork. Use them when the user's diagram needs them; upstream rejects them, so a candidate that uses them renders only with this fork.

## Architecture connections

| Field | Type | Effect |
|---|---|---|
| `bidirectional` | boolean | Draws an arrowhead at both ends for a two-way exchange (read/write, sync). Keep `from` as the side that starts the exchange. |

Browser checks measure both ends: each end needs a visible shaft behind its arrowhead, and a single straight run must fit both heads plus the shaft.

## Architecture components

| Field | Type | Effect |
|---|---|---|
| `note` | string | Role or responsibility text shown under the detail line of the Semantic Passport when the node is focused. Not drawn on the canvas, so it can be longer than `sublabel`; line breaks are kept. |

A diagram that uses `note` carries one small fork script after the SVG; diagrams without notes are unchanged.

## Architecture boundaries

| Field | Type | Effect |
|---|---|---|
| `id` | id | Makes the boundary clickable. |
| `note` | string | Description shown when the boundary is clicked. A note alone also makes it clickable. |

Clicking the boundary frame or label (or Enter on the focused label) opens a panel with the note and the wrapped components; choosing a component opens its Semantic Passport. Escape or a click elsewhere closes it.

## Architecture facets

Facets are concepts the diagram wants to show on every component, defined per diagram: a service provider, an owning team, a delivery stage, and so on. Declare each facet and its values at the top level, then pick a value per facet on components.

```json
"facets": [
  { "id": "provider", "label": "Provider", "values": [
    { "id": "aws", "label": "AWS" },
    { "id": "ours", "label": "In-house", "color": "#2D6CDF" }
  ] },
  { "id": "stage", "label": "Stage", "marker": "none", "values": [
    { "id": "base", "label": "Base" }, { "id": "ext", "label": "Extension" }
  ] }
],
"components": [{ "id": "api", "type": "backend", "label": "API", "facets": { "provider": "ours", "stage": "base" } }]
```

| Field | Type | Effect |
|---|---|---|
| `facets[].id` / `label` | id / string | Unique facet id and the name shown in the passport. |
| `facets[].marker` | `stripe-left` · `stripe-right` · `none` | Canvas marker. Default: the first facet `stripe-left`, others `none`. Each stripe side can be used by one facet. |
| `facets[].values[]` | `{ id, label, color? }` | Allowed values; `color` is `#RRGGBB`, otherwise a fixed palette in list order. |
| `components[].facets` | object | Facet id → value id; both must be declared, or rendering fails. |

A stripe facet draws a thin colored stripe inside the card edge and adds legend rows for the values in use (prefixed with the facet label when two facets have stripes; omitted when the legend is hidden). Every picked value appears as a colored `Facet: Value` chip in the Semantic Passport.

## Architecture variants

Variants let one diagram hold alternative designs that the reader switches between in the viewer.

```json
"variants": [
  { "id": "host", "label": "FE/BE hosting", "options": [{ "id": "ecs", "label": "ECS Fargate" }, { "id": "apps", "label": "Databricks Apps" }] },
  { "id": "ingest", "label": "Ingestion", "default": "k", "options": [{ "id": "d", "label": "Batch" }, { "id": "k", "label": "Streaming" }] }
],
"components": [
  { "id": "ecs", "type": "backend", "label": "ECS", "pos": [300, 225], "when": { "host": "ecs" } },
  { "id": "apps", "type": "backend", "label": "Apps", "pos": [300, 225], "when": { "host": "apps" } }
]
```

| Field | Type | Effect |
|---|---|---|
| `variants[]` | `{ id, label, default?, options[] }` | Each variant has two or more options; `default` (else the first option) is shown first. |
| `variants[].when` | object | Earlier variant choices under which this variant applies. The panel nests it under the last variant it names, with the condition spelled out; otherwise its buttons are disabled, it stays at its default, and its combinations are checked once. |
| `variants[].options[].pros` / `cons` | string | Trade-offs shown beside the option on hover or keyboard focus. |
| `when` on components, connections, boundaries | object | Variant id → option id or list of ids. The element shows only when every listed variant matches. |

Rules:

- Elements that never appear together may share a position.
- A connection disappears with either endpoint; a boundary keeps only its visible members and disappears when none remain.
- Every combination (at most 256) is rendered on its own and must pass the normal layout checks; a failure names the combination. Each combination's routes, label positions and boundary boxes are the ones the viewer applies.
- The delivered SVG is the default combination; the other elements wait as markup and join the diagram when a combination needs them. A "구성 선택"/"Variants" panel at the top right switches options.
- Legend counts and the node list follow the chosen combination. Hidden elements drop their node and edge hooks, so focus highlights, relationship lists and search ignore them.

## Architecture text sizes

`meta.textSize` sets the preferred px size of each text kind. Every field is optional (6–32); a missing one keeps its default.

```json
"meta": { "title": "…", "output": "…", "textSize": { "label": 14, "sublabel": 11, "edgeLabel": 11, "boundaryLabel": 12 } }
```

| Field | Default | Effect |
|---|---|---|
| `label` | 11 (shrinks to 8) | Card name. Shrinks to fit the card, never below 8 (or the chosen size if smaller). The static name-overflow check measures at the smaller of this size and 11. |
| `sublabel` | 9 (shrinks to 6) | Card description. Shrinks to fit, like the name. |
| `edgeLabel` | 8 | Connection label. Its mask is `units × 0.6 × size + 10` wide and `size + 6` tall, growing upward so its bottom stays 4px under the baseline. |
| `boundaryLabel` | 9 | Boundary title. The title rail, its mask and the frame use this size, with the gap to the cards and stacked titles below widened by the extra descent. |

With a `label` or `sublabel` size, the two text rows are spaced for their sizes and centred in the card. With any size set, cards with an icon slot (`iconImage` or `iconSlot`) fit their text to the space beside the slot, so long text on a narrow card shrinks below the chosen size; widen the card to keep it (needed width ≈ `text units × 0.6 × size + 50` with a slot, `+ 8` without, where a CJK character counts as 2 units). Masks, overlap checks, automatic label placement, variant combinations and browser checks all use the same sizes. Diagrams without `textSize` render unchanged.

## Viewer shortcuts

`"shortcuts": false` at the top level turns off the viewer's single-key shortcuts (T theme, S style, E export, F, M, L, R, /, ?, +, -, 0) and hides their hints. Escape, Enter and arrow keys keep working, and typing in any field — including fields inside shadow-DOM widgets — is unaffected.

## Node icon images

`components[].iconImage` takes a self-contained `data:image/svg+xml;base64,…` or `data:image/png;base64,…` URI (up to 200,000 characters) and gives the card a 28×28 icon slot on its left, vertically centred, drops the type sigil and centres the text in the remaining width. Use it for official service icons (for example AWS Architecture Icons) that the author keeps beside the diagram; the fork bundles no third-party artwork. The artifact stays offline because the image is embedded.

Top-level `"iconSlot": true` gives every card the same left slot and fills it with the card's type sigil scaled to 28×28 (or its `iconImage`), so all cards share one layout.

Browser checks measure graphic quality in every variant combination (`graphics.combinations` in the receipt); an issue found only in a non-default combination names it as `variant combination <key>`.

`components[].sigil` draws an extra line glyph in place of the type sigil, in the same tone and place (inside the icon slot too): `users`, `database-import`, `workflow`, `waves`, `database-sync`, `database-zap`, `database-search`, `table`, `timer`, `database-table` (a database with a small table, drawn for the fork). The other glyphs come from Lucide (ISC) and Tabler Icons (MIT); their licences are in `renderers/fork/THIRD_PARTY_ICONS.md`.
